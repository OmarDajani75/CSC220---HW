//Homework #2
//Student.java
//Omar Dajani
public class Student extends Human {
    private final String firstName;
    int student_num;

    public Student(String firstName, String lastName, int student_num) {
        super(firstName, lastName);
        this.firstName = firstName;
        this.lastName = lastName;
        this.student_num = student_num;
    }

    public int getStudent_num() {
        return student_num;
    }

    public int setStudent_num() {
       return student_num;
    }

    @Override
    public String toString() {
        return "Student{" +
                "student_num=" + student_num +
                '}';
    }


    public int compareTo(Object o){
        return (this.getStudent_num() < ((Student) o).getStudent_num() ? - 1 : (this.getStudent_num() == ((Student) o).getStudent_num() ? 0 : 1));
    }
}
