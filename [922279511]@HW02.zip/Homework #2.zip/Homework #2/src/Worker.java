//Homework #2
//Worker.java
//Omar Dajani
public class Worker extends Human {
    double WeekSalary;
    int WorkHoursPerDay;

    public Worker(String firstName, String lastName, int workHoursPerDay) {
        super(firstName, lastName);
        WorkHoursPerDay = workHoursPerDay;
    }

    public double getWeekSalary() {
        return WeekSalary;
    }

    public void setWorkHoursPerDay(int workHoursPerDay) {
        WorkHoursPerDay = workHoursPerDay;
    }

    public void setWeekSalary(double weekSalary) {
        WeekSalary = weekSalary;
    }

    @Override
    public String toString() {
        return "Worker{" +
                "WeekSalary=" + WeekSalary +
                ", WorkHoursPerDay=" + WorkHoursPerDay +
                '}';
    }

    public int getWorkHoursPerDay() {
        return WorkHoursPerDay;
    }

    public Worker(String firstName, String lastName, double weekSalary, int WorkHoursPerDay) {
        super(firstName, lastName);
        WeekSalary = weekSalary;
    }

    public void MoneyPerHour(int WorkHoursPerDay) {

    }
}
