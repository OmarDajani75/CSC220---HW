/* Homework #8
Main.java
Omar Dajani
 */
import java.util.*;
    public class Main {


        public static void initializeBuilding(LinkedList<Passenger> floor1, LinkedList<Passenger> floor2, LinkedList<Passenger> floor3, LinkedList<Passenger> floor4, LinkedList<Passenger> floor5, LinkedList<LinkedList<Passenger>> building) {
            int ranNumb = (int) Math.floor(Math.random() * (5 + 1) + 0);
            for(int i = 0; i < ranNumb; i++) {
                int randNumb2 = (int) Math.floor(Math.random() * (5 -1 + 1) + 1);
                while (randNumb2 == 1) {
                    randNumb2 = (int) Math.floor(Math.random() * (5 -1 + 1) + 1);
                }
                Passenger p = new Passenger(i,1, randNumb2);
                floor1.add(p);
            }
            ranNumb = (int) Math.floor(Math.random() * (5 + 1) + 0);
            for(int i = 0; i < ranNumb; i++) {
                int randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                while (randNumb2 == 2) {
                    randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                }
                Passenger p = new Passenger(i, 2, randNumb2);
                floor2.add(p);
            }
            ranNumb = (int) Math.floor(Math.random() * (5 + 1) + 0);
            for(int i = 0; i < ranNumb; i++) {
                int randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                while (randNumb2 == 3) {
                    randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                }
                Passenger p = new Passenger(i, 3, randNumb2);
                floor3.add(p);
            }
            ranNumb = (int) Math.floor(Math.random() * (5 + 1) + 0);
            for(int i = 0; i < ranNumb; i++) {
                int randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                while (randNumb2 == 4) {
                    randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                }
                Passenger p = new Passenger(i, 4, randNumb2);
                floor4.add(p);
            }
            ranNumb = (int) Math.floor(Math.random() * (5 + 1) + 0);
            for(int i = 0; i < ranNumb; i++) {
                int randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                while (randNumb2 == 5) {
                    randNumb2 = (int) Math.floor(Math.random() * (5 - 1 + 1) + 1);
                }
                Passenger p = new Passenger(i, 5, randNumb2);
                floor5.add(p);
            }
            building.add(floor1);
            building.add(floor2);
            building.add(floor3);
            building.add(floor4);
            building.add(floor5);
        }

        public static void printBuilding(LinkedList<LinkedList<Passenger>> building) {
            System.out.println("Building has 5 floors");
            for(int i = 0; i < 5; i++){
                System.out.println("========================");
                System.out.println("floor" + (i+1) + " (" + building.get(i).size() + ") passengers waiting");
                for(int j = 0; j < building.get(i).size(); j++){
                    System.out.println(building.get(i).get(j));
                }
            }
        }

        public void startElevator(LinkedList<LinkedList<Passenger>> building, LinkedList<Passenger> Elevator) {
            System.out.println("Elevator has started");
            for (int i = 0; i < 5; i++) {
                int count = 0;
                int remCount = 0;
                int size = building.get(i).size();

                for (int j = 0; j < size; j++) {
                    Elevator.add(building.get(i).get(j));
                    count++;
                }
                if (i + 1 == 1) {
                    if (count != 0) {
                        System.out.println("At floor " + (i + 1) + ", elevator picked" + count + " passengers");
                    }
                    System.out.println("Going up");
                }
                if (count != 0 && i + 1 != 1) {
                    System.out.println("Stopped at floor " + (i + 1) + " elevator picked " + count + "passengers" + ", # of passengers now");
                }
                LinkedList<Passenger> tmp = new LinkedList<>();
                int s = Elevator.size();
                for (int j = 0; j < s; j++) {
                    if (!Elevator.isEmpty()) {
                        if (Elevator.peek().getDestinationFloor() == i + 1) {
                            Elevator.remove();
                            remCount++;
                        } else {
                            tmp.add(Elevator.remove());
                        }
                    }
                    while (!tmp.isEmpty()) {
                        Elevator.add(tmp.remove());
                    }
                    if (i + 1 != 1 && i + 1 != 5) {
                        if (count == 0) {
                            System.out.println("Floor: " + (i + 1));
                        }
                        System.out.println("Elevator served " + remCount + " passengers, # of passengers now " + Elevator.size());
                        System.out.println("Going up");
                    }
                }
                if (i + 1 == 5) {
                    if (count == 0) {
                        System.out.println("Floor " + (i + 1));
                    }
                    System.out.println("Elevator served " + remCount + " passengers, # of passengers now " + Elevator.size());
                    System.out.println("Going down");
                }
                System.out.println("=======================");
            }
            for (int i = 4; i >= 0; i--) {
                int remCount = 0;
                LinkedList<Passenger> tmp = new LinkedList<>();
                int s = Elevator.size();
                for (int j = 0; j < s; j++) {
                    if (!Elevator.isEmpty()) {
                        if (Elevator.peek().getDestinationFloor() == i + 1) {
                            Elevator.remove();
                            remCount++;
                        } else {
                            tmp.add(Elevator.remove());
                        }
                    }
                }
                while (!tmp.isEmpty()) {
                    Elevator.add(tmp.remove());
                }
                if (i + 1 != 5 && i + 1 != 1 && remCount != 0) {
                    System.out.println("Stopped at floor " + (i + 1) + " elevator served " + remCount + " passengers, # of passengers now " + Elevator.size());
                    if (Elevator.size() != 0) {
                        System.out.println("Going down");
                        System.out.println("====================");
                    }
                }
                if (i + 1 == 1 && remCount != 0) {
                    System.out.println("Stopped at floor " + (i + 1) + " elevator served " + remCount + " passengers, # of passengers now " + Elevator.size());
                }
            }
        }

        public static void main(String[] args) {
            LinkedList<Passenger> Elevator = new LinkedList<>();
            LinkedList<Passenger> floor1 = new LinkedList<>();
            LinkedList<Passenger> floor2 = new LinkedList<>();
            LinkedList<Passenger> floor3 = new LinkedList<>();
            LinkedList<Passenger> floor4 = new LinkedList<>();
            LinkedList<Passenger> floor5 = new LinkedList<>();
            LinkedList<LinkedList<Passenger>> building = new LinkedList<>();
            initializeBuilding(floor1, floor2, floor3, floor4, floor5, building);
            printBuilding(building);
        }
    }
