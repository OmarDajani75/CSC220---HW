package edu.sfsu;
import java.util.Arrays;

/**
 *
 * @author abeer
 */
public class ArrayStack<T> implements StackInterface<T> {

    private T[] stack;
    private int topIndex;
    private static final int DEFAULT_INITIAL_CAPACITY = 50;

    public ArrayStack() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    public ArrayStack(int initialCapacity) {
        T[] temporaryStack = (T[]) new Object[initialCapacity];
        stack = temporaryStack;
        topIndex = -1;
    }

    private void ensureCapacity() {
        if (topIndex == stack.length - 1)
        {
            stack = Arrays.copyOf(stack, 2 * stack.length);
        }
    }

    @Override
    public void push(T entry) {
        ensureCapacity();
        topIndex++;
        stack[topIndex] = entry;
    }

    @Override
    public T pop() {
        T top = null;
        if (!isEmpty()) {
            top = stack[topIndex];
            stack[topIndex] = null;
            topIndex--;
        }
        return top;
    }

    @Override
    public T peek() {
        T top = null;
        if (!isEmpty()) {
            top = stack[topIndex];
        }
        return top;
    }

    @Override
    public boolean popN(int entry){
        if(topIndex + 1 >= entry){
            topIndex = topIndex - entry;
            return true;
        }
        return false;
    }

    @Override
    public boolean isEmpty() {
        return topIndex < 0;
    }

}
