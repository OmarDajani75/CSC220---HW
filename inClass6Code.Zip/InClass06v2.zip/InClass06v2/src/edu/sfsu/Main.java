package edu.sfsu;
import java.util.Scanner;

public class Main {
    static void printStack(NodeStack s) {
        NodeStack<Integer> backup = new NodeStack<>();
        System.out.println("Stack contents:");
        while (!s.isEmpty()) {
            int o = (Integer)s.pop();
            backup.push(o);
            System.out.print(o + " ");
        }
        System.out.println();

        while(!backup.isEmpty())
            s.push(backup.pop());
    }
    public static void main(String[] args) {
        int choice = -1;
        NodeStack<Integer> stk = new NodeStack<>();
        do {
            System.out.println("[1] To push an item into the stack");
            System.out.println("[2] To pop an item from the stack");
            System.out.println("[3] To print the top of stack");
            System.out.println("[4] To check of stack is empty");
            System.out.println("[5] To print stack contents");
            System.out.println("[6] To remove n number of items");
            System.out.println("[7] To Exit");
            System.out.println("Enter your choice:");
            Scanner in = new Scanner(System.in);
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter an item");
                    int num = in.nextInt();
                    stk.push(num);
                    break;
                case 2:
                    if (!stk.isEmpty()) {
                        stk.pop();
                    }
                    break;
                case 3:
                    if (!stk.isEmpty()) {
                        System.out.println("Top of the stack is " + stk.peek());
                    } else {
                        System.out.println("Stack is empty ");
                    }
                    break;
                case 4:
                    if (stk.isEmpty()) {
                        System.out.println("Stack is empty");
                    }else {
                        System.out.println("Stack is not empty");
                    }
                    break;
                case 5:
                    printStack(stk);
                    break;
                case 6:
                    NodeStack<Integer> temp = new NodeStack<>();
                    int size = 0;
                    while (!stk.isEmpty()){
                        temp.push(stk.pop());
                        size++;
                    }
                    while (!temp.isEmpty()){
                        stk.push(temp.pop());
                    }
                    System.out.println("How many items do you want to remove from the stack?");
                    num = in.nextInt();
                    if(size >= num){
                        stk.popN(num);
                        System.out.println("Items removed successfully");
                    }else{
                        System.out.println("Items failed to be removed");
                    }
                    break;
                case 7:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice! Enter a number in range [1-6]");
                    break;
            }
        } while (choice != 6);
    }
}
