//Homework #6
//Main.java
//Omar Dajani
package edu.sfsu;

import java.util.Scanner;

public class Main {
    static void printStack(ArrayStack s) {
        ArrayStack<Integer> backup = new ArrayStack<>();
        System.out.println("Stack contents:");
        while (!s.isEmpty()) {
            int t = (Integer)s.pop();
            backup.push(t);
            System.out.print(t + " ");
        }
        System.out.println();

        while(!backup.isEmpty())
            s.push(backup.pop());
    }
    static void printStack2(ArrayStack s) {
        ArrayStack<Integer> backupTwo = new ArrayStack<>();
        System.out.println("Stack contents:");
        while (!s.isEmptyTwo()) {
            int t = (Integer)s.popTwo();
            backupTwo.pushTwo(t);
            System.out.print(t + " ");
        }
        System.out.println();

        while(!backupTwo.isEmpty())
            s.push(backupTwo.popTwo());
    }

    public static void main(String[] args) {
        ArrayStack<Integer> stk = new ArrayStack<>();

        int choice = -1;

        do {
            System.out.println("[1] To push an item into the first stack");
            System.out.println("[2] To push an item into the second stack");
            System.out.println("[3] To pop an item from the first stack");
            System.out.println("[4] To pop an item from the second stack");
            System.out.println("[5] To print the top of the first stack");
            System.out.println("[6] To print the top of the second stack");
            System.out.println("[7] To print first stack contents");
            System.out.println("[8] To print second stack contents");
            System.out.println("[9] To Exit");
            System.out.println("Enter your choice:");
            Scanner in = new Scanner(System.in);
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter an item");
                    int num = in.nextInt();
                    stk.push(num);
                    break;
                case 2:
                    System.out.println("Enter an Item");
                    num = in.nextInt();
                    stk.pushTwo(num);
                case 3:
                    if (!stk.isEmpty()) {
                        stk.pop();
                    }
                    //if (!stk.isEmpty())
                        //System.out.println("Top of the stack is " + stk.peek());
                    //else
                        //System.out.println("Stack is empty");
                    //break;
                case 4:
                    if (!stk.isEmptyTwo()) {
                        stk.popTwo();
                    }
                case 5:
                    if (stk.isEmpty())
                        System.out.println("Top of the stack is as follows: " +stk.peek());
                     else
                        System.out.println("Stack 1 is empty");
                    break;
                case 6:
                    if (stk.isEmptyTwo())
                        System.out.println("Top of the second stack is as follows: " +stk.peekTwo());
                    else
                        System.out.println("Stack 2 is empty");
                    break;
                case 7:
                    printStack(stk);
                    break;
                case 8:
                    printStack2(stk);
                    break;
                case 9:
                    System.out.println("Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice! Enter a number in the range [1-8]");
                    break;
            }
        } while (choice != 9);
    }
}
