/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

//Homework #6
//Main.java
//Omar Dajani
package edu.sfsu;

import java.util.Arrays;

/**
 *
 * @author abeer
 */
public class ArrayStack<T> implements StackInterface<T> {

    private T[] stack; // array of stack entries
    private int topIndex; // index of top entry
    private int bottomIndex;
    private static final int DEFAULT_INITIAL_CAPACITY = 3;

    public ArrayStack() {
        this(DEFAULT_INITIAL_CAPACITY);
    }

    public ArrayStack(int initialCapacity) {
        // the cast is safe because the new array contains null entries
        @SuppressWarnings("unchecked")
        T[] tempStack = (T[]) new Object[initialCapacity];
        stack = tempStack;
        topIndex = -1;
        //Finding the length
        bottomIndex = initialCapacity;
    }

    private void ensureCapacity() {
        if (topIndex >= -1 + bottomIndex) {
            T[] temp = (T[]) new Object[stack.length - bottomIndex];
            for (int i = 0; i < temp.length; i++) {
                temp[1] = popTwo();
            }
            stack = Arrays.copyOf(stack, 2 * stack.length);
            for (int i = (temp.length - 1); i > 0; i--) {
                pushTwo(temp[1]);
            }
        }
    }
     // end ensureCapacity

    @Override
    public void push(T entry) {
        ensureCapacity();
        topIndex++;
        stack[topIndex] = entry;
    }

    public void pushTwo(T entry) {
        ensureCapacity();
        bottomIndex--;
        stack[bottomIndex] = entry;

    }

    @Override
    public T pop() {
        T top = null;
        if (!isEmpty()) {
            top = stack[topIndex];
            stack[topIndex] = null;
            topIndex--;
        } // end if
        return top;
    }

    public T popTwo() {
        T top = null;
        if (!isEmpty()) {
            top = stack[bottomIndex];
            stack[bottomIndex] = null;
            bottomIndex++;
        } // end if
        return top;
    }

    @Override
    public T peek() {
        T top = null;
        if (!isEmpty()) {
            top = stack[topIndex];
        }
        return top;
    }

    public T peekTwo() {
        T top = null;
        if (!isEmpty()) {
            top = stack[bottomIndex];
        }
        return top;
    }

    @Override
    public boolean isEmpty() {
        return topIndex < 0;
    }

    public boolean isEmptyTwo() {
        return bottomIndex > (stack.length - 1);
    }

}
