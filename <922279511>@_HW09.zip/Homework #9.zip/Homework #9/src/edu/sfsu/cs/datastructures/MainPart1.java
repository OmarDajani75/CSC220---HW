package edu.sfsu.cs.datastructures;
/* Homework #9
edu.sfsu.cs.datastructures.Main.java
Omar Dajani
 */
import java.io.*;
import java.util.*;

public class MainPart1 {
    /*
     * Question 1:
     * - In this question you will use the Data.users array that includes
     * a list of users. Formatted as : firstname,lastname,age,email,gender,city,state
     * - Create a edu.sfsu.cs.datastructures.User class that should parse all the parameters for each user.
     * - Insert each of the users in a list.
     * - Print out the TOP 10 oldest users.
     * */

    public static void main(String[] args) {

        LinkedList<User> userList = new LinkedList<>();

        //example on how to access the Data.users array.
        for (String str : edu.sfsu.cs.datastructures.Data.users) {
            String[] user = str.split(",");
            userList.add(new User(user[0], user[1], user[2], user[3], user[4], user[5], user[6]));
        }
    }
}
