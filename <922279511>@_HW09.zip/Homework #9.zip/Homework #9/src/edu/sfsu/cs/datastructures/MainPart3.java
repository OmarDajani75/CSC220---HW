package edu.sfsu.cs.datastructures;
/* Homework #9
edu.sfsu.cs.datastructures.Main.java
Omar Dajani
 */

public class MainPart3 {
//    In this question you will use the Data.users and Data.otherUsers arrays that include a list of users. You are asked to perform the following tasks:
//            1.  Your implementation for this question should be included in edu.sfsu.cs.datastructures.MainPart2.java.
//2.  The  goal  is  to  print  out  the  users  that  are  exist  in  both  the  Data.users  and
//    Data.otherUsers. Two users are equal if all their attributes are equal.
//3.  Print out the list of users which exist in both Data.users and Data.otherUsers. The
//    printed list of users should be sorted by state in descending order.

    public static void main(String[] args) {

    }
}
