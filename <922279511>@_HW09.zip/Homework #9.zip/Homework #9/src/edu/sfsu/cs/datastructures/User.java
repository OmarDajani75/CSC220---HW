package edu.sfsu.cs.datastructures;/* Homework #9
edu.sfsu.cs.datastructures.Main.java
Omar Dajani
 */
import java.util.*;
public class User implements Comparable{
    private String firstname;
    private String lastname;
    private String age;
    private String email;
    private String gender;
    private String city;
    private String state;

    public User(String firstname, String lastname, String age, String email, String gender, String city, String state) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.city = city;
        this.state = state;
    }

    public String getFirstname() {
        return firstname;
    }

    public String getLastname() {
        return lastname;
    }

    public String getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getCity() {
        return city;
    }

    public String getState() {
        return state;
    }

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public void setAge(String age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public void setState(String state) {
        this.state = state;
    }

    @Override
    public int compareTo(Object o) {
        return (Integer.parseInt(this.getAge()) < Integer.parseInt(((User) o).getAge()) ? 1 : (Integer.parseInt(this.getAge()) == Integer.parseInt(((User) o).getAge()) ? 0 : -1));
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof User)) return false;
        User user = (User) o;
        return getAge() == user.getAge() && getFirstname().equals(user.getFirstname()) && getLastname().equals(user.getLastname()) && getEmail().equals(user.getEmail()) && getGender().equals(user.getGender()) && getCity().equals(user.getCity()) && getState().equals(user.getState());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstname(), getLastname(), getAge(), getEmail(), getGender(), getCity(), getState());
    }

    @Override
    public String toString() {
        return "edu.sfsu.cs.datastructures.User{" +
                "firstname='" + firstname + '\'' +
                ", lastname='" + lastname + '\'' +
                ", age=" + age +
                ", email='" + email + '\'' +
                ", gender='" + gender + '\'' +
                ", city='" + city + '\'' +
                ", state='" + state + '\'' +
                '}';
    }
}
