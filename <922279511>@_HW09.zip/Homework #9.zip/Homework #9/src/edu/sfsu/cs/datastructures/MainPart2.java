package edu.sfsu.cs.datastructures;
/* Homework #9
edu.sfsu.cs.datastructures.Main.java
Omar Dajani
 */

public class MainPart2 {
//    Using the same Data.users array. You are asked to perform the following tasks:
//            1.  Your implementation for this question should be included in MainPart1.java file.
//            2.  The goal is to count the number of users living each state. Print out the list of State,
//    Count order in ascending order by count.

    public static void main(String[] args) {

    }
}

