package edu.sfsu;

/**
 *
 * @author abeer
 */
public interface StackInterface<T> {
    public void push(T entry);
    public T pop();
    public T peek();
    public boolean isEmpty();
    public boolean popN(int entry);
}