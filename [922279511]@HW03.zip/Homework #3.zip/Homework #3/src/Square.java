//Homework #3
//Square.java
//Omar Dajani
public class Square extends Rectangle {
    private double side;

    public Square(double side, String color, boolean filled) {
        super(color, filled);
        //The order of parameters is different here. Incompatible data types with the super class.
        this.width = width;
        this.length = length;
    }

    public Square(double side) {
        this.side = side;
    }

    public Square() {
    }

    public double getSide(double side) {
        return this.side;
        //Square has the instance of side, but the rectangular does not. It only has length and width.
    }

    public void setSide(double side) {
      super.width = side;
      super.length = side;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public void setLength(double length) {
        this.length = length;
    }

    @Override
    public String toString() {
            return side + "," +  + '\'' +
                    + width + '\'' + length;
    }
}
