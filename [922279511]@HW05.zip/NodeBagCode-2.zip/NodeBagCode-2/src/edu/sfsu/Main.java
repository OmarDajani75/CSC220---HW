//Homework #5
//Main.java
//Omar Dajani
package edu.sfsu;

import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        NodeBasedBag<Coin> bag = new NodeBasedBag<>();
        int choice = -1;

        do {
            System.out.println("[1] To add a new coin to the bag");
            System.out.println("[2] To remove an coin from the bag");
            System.out.println("[3] To remove a specific coin from the bag");
            System.out.println("[4] To clear the bag");
            System.out.println("[5] To get a frequency of a given coin in the bag");
            System.out.println("[6] To check if a specific coin exists in the bag");
            System.out.println("[7] To get minimum coin value");
            System.out.println("[8] To get maximum coin value");
            System.out.println("[9] To print the contents of the bag");
            System.out.println("[10] To print the contents of the bag but in orderly fashion");
            System.out.println("[11] To exit");
            System.out.println("Enter your choice:");
            Scanner in = new Scanner(System.in);
            choice = in.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter coin:");
                    int x = in.nextInt();
                    Coin coin = new Coin(x);
                    if (x == 10 || x == 25 || x == 75 || x == 100)
                    if (bag.add(coin)) {
                        System.out.println("edu.sfsu.Coin " + coin + " is added successfully to the bag");
                    }
                    break;
                case 2:
                    if (bag.isEmpty()) {
                        System.out.println("Bag is empty!");
                    } else {
                        System.out.println("edu.sfsu.Coin " + bag.remove() + " is removed successfully");
                    }
                    break;
                case 3:
                    System.out.println("Enter the coin you want to remove from the bag:");
                    x = in.nextInt();
                    coin = new Coin(x);
                    if (bag.contains(coin)) {
                        bag.remove(coin);
                        System.out.println("edu.sfsu.Coin " + coin + " is removed from the bag");
                    } else {
                        System.out.println("The coin " + coin + " doesn't exist in the bag");
                    }
                    break;
                case 4:
                    bag.clear();
                    System.out.println("Bag is empty now!");
                    break;
                case 5:
                    System.out.println("Enter the coin you are checking the frequency of:");
                    x = in.nextInt();
                    coin = new Coin(x);
                    System.out.println("The coin " + coin + " is found " + bag.getFrequencyOf(coin) + " times");
                    break;
                case 6:
                    System.out.println("Enter the coin you are looking for:");
                    x = in.nextInt();
                    coin = new Coin(x);
                    if (bag.contains(coin)) {
                        System.out.println("The coin " + coin + " is in the bag");
                    } else {
                        System.out.println("The coin " + coin + " is NOT in the bag");
                    }
                    break;
                case 7:
                    if (bag.isEmpty()) {
                        System.out.println("Bag is empty!");
                    } else {
                        System.out.println("Minimum value is ");
                        bag.minVal();
                    }
                       break;
                case 8:
                    if (bag.isEmpty()) {
                        System.out.println("Bag is empty!");
                    } else {
                        System.out.println("Maximum value is ");
                        bag.maxVal();
                    }
                    break;
                default:
                    System.out.println("Invalid choice! Enter a number in the range [1-8]");
                    break;
                case 9:
                    if (bag.isEmpty()) {
                        System.out.println("Bag is empty!");
                    } else {
                        System.out.println("Bag content:");
                        System.out.println(Arrays.toString(bag.toArray()));
                    }
                    break;

                case 10:
                    System.out.println(Arrays.toString(bag.sortArray()));
                    break;
                case 11:
                    System.out.println("Goodbye!");
                    break;
            }
        } while (choice != 11);
    
    }
}